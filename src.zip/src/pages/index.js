import React, { useContext } from "react";
import { UserContext } from "../UserContext";
import { login } from "../utils/login";

export function Index() {
  const { user, setUser,userId } = useContext(UserContext);
  const usrLogin=async()=>{
    const user = await login();
    setUser(user);
  }
  return (
    <div>
      <h2>Home</h2>
      <pre>{JSON.stringify(user, null, 2)}</pre>
      <pre>{JSON.stringify(userId, null, 2)}</pre>
      {user ? (
        <button
          onClick={() => {
            // call logout
            setUser(null);
          }}
        >
          logout
        </button>
      ) : (
        <button
          onClick={usrLogin}
        >
          login
        </button>
      )}
    </div>
  );
}
