import React, { useContext } from "react";
import { UserContext } from "../UserContext";
import { login1 } from "../utils/login1";
export function Employee() {
  const { user,setUser,userId,setUserId} = useContext(UserContext);
  let usernewid="1231312";
  const usrLogin=async()=>{
    const user = await login1();
    setUser(user);
     setUserId({usernewid});
  }
  return (
    <div>
      <h2>About</h2>
      <pre>{JSON.stringify(user, null, 2)}</pre>
      <pre>{JSON.stringify(userId, null, 2)}</pre>
      <button
          onClick={usrLogin}
        >
          login
        </button>
    </div>
  );
}
