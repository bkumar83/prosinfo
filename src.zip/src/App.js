import React, { useState, useMemo } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { Index } from "./pages";
import { About } from "./pages/about";
import { UserContext } from "./UserContext";
import {Employee} from "./pages/employee";
function AppRouter() {
  const [user, setUser] = useState(null);
  const [userId,setUserId] = useState(null);
  const value = useMemo(() => ({ user, setUser,userId,setUserId }), [user, setUser,userId,setUserId]);

  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about/">About</Link>
            </li>
            <li>
              <Link to="/employee/">Employee</Link>
            </li>
          </ul>
        </nav>
        <UserContext.Provider value={value}>
          <Route path="/" exact component={Index} />
          <Route path="/about/" component={About} />
          <Route path="/employee/" component={Employee} />
        </UserContext.Provider>
      </div>
    </Router>
  );
}

export default AppRouter;
