export const login1 = async () => {
  return {
    id: 5,
    username: "Test",
    email: "test@bob.com"
  };
};
