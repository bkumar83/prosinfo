export const login = async () => {
  return {
    id: 4,
    username: "bob",
    email: "bob@bob.com"
  };
};
